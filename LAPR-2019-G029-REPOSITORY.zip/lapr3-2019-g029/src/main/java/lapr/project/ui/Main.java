package lapr.project.ui;

import lapr.project.assessment.Facade;
import lapr.project.controller.ShortestRouteBetweenParksController;
import lapr.project.data.Bootstrap;
import lapr.project.data.Emailer;
import lapr.project.data.Shutdown;
import lapr.project.data.registers.Company;
import lapr.project.data.registers.InvoiceAPI;
import lapr.project.data.registers.TripAPI;
import lapr.project.data.registers.VehicleAPI;
import lapr.project.model.Coordinates;
import lapr.project.model.Invoice;
import lapr.project.model.Trip;
import lapr.project.model.point.of.interest.park.Park;
import lapr.project.model.vehicles.*;
import lapr.project.utils.InvalidFileDataException;
import lapr.project.utils.UnregisteredDataException;

import javax.mail.MessagingException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

class Main {

    /**
     * Logger class.
     */
    private static final Logger LOGGER = Logger.getLogger("MainLog");

    /**
     * Private constructor to hide implicit public one.
     */
    private Main() {

    }

    /**
     * Application main method.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Bootstrap.boot();
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        //<editor-fold desc="test update park">
//            Company.getInstance().getParkRegister().updateParkId("park1", "cool doggo park");
//            Company.getInstance().getParkRegister().updateParkCapacity("cool doggo park", VehicleType.BICYCLE, 99);
//            Company.getInstance().getParkRegister().updateParkCapacity("cool doggo park", VehicleType.ELECTRIC_SCOOTER, 88);
//            Company.getInstance().getParkRegister().updateParkDescription("cool doggo park", "FOR ALL FRIENDLY DOGGIES!");
//            Company.getInstance().getParkRegister().updateParkInputVoltage("cool doggo park", 1111.1f);
//            Company.getInstance().getParkRegister().updateParkInputCurrent("cool doggo park", 999.9f);
        //</editor-fold>

        //<editor-fold desc="test fetch vehicle">
//            Vehicle bike = Company.getInstance().getVehicleRegister().fetchVehicle(11);
//            Vehicle scooter = Company.getInstance().getVehicleRegister().fetchVehicle(14);
//            Bicycle b = (Bicycle) bike;
//            ElectricScooter s = (ElectricScooter) scooter;
//            System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="Batch register electric scooters">
//            List<Float> aerodynamicCoefficient = new ArrayList<>();
//            aerodynamicCoefficient.add(1.1f);
//            aerodynamicCoefficient.add(1.2f);
//            List<Float> frontalArea = new ArrayList<>();
//            frontalArea.add(2.1f);
//            frontalArea.add(2.2f);
//            List<Integer> weight = new ArrayList<>();
//            weight.add(3);
//            weight.add(4);
//            List<ElectricScooterType> type = new ArrayList<>();
//            type.add(ElectricScooterType.OFFROAD);
//            type.add(ElectricScooterType.URBAN);
//            List<String> description = new ArrayList<>();
//            description.add("desc1");
//            description.add("desc2");
//            List<Float> maxBatteryCapacity = new ArrayList<>();
//            maxBatteryCapacity.add(5.1f);
//            maxBatteryCapacity.add(5.2f);
//            List<Integer> actualBatteryCapacity = new ArrayList<>();
//            actualBatteryCapacity.add(6);
//            actualBatteryCapacity.add(7);
//            List<Integer> enginePower = new ArrayList<>();
//            enginePower.add(8);
//            enginePower.add(9);
//            List<Double> parkLatitude = new ArrayList<>();
//            parkLatitude.add(10.2);
//            parkLatitude.add(10.2);
//            List<Double> parkLongitude = new ArrayList<>();
//            parkLongitude.add(10.5);
//            parkLongitude.add(10.5);
//            Company.getInstance().getVehicleRegister().registerElectricScooters(aerodynamicCoefficient, frontalArea, weight,
//                    type, description, maxBatteryCapacity, actualBatteryCapacity, enginePower, parkLatitude, parkLongitude);
        //</editor-fold>

        //<editor-fold desc="Batch register bicycles">
//            List<Float> aerodynamicCoefficient2 = new ArrayList<>();
//            aerodynamicCoefficient2.add(1.1f);
//            aerodynamicCoefficient2.add(1.2f);
//            List<Float> frontalArea2 = new ArrayList<>();
//            frontalArea2.add(2.1f);
//            frontalArea2.add(2.2f);
//            List<Integer> weight2 = new ArrayList<>();
//            weight2.add(3);
//            weight2.add(4);
//            List<Integer> size2 = new ArrayList<>();
//            size2.add(5);
//            size2.add(6);
//            List<String> description2 = new ArrayList<>();
//            description2.add("desc3");
//            description2.add("desc4");
//            List<Double> parkLatitude = new ArrayList<>();
//            parkLatitude.add(-80.222);
//            parkLatitude.add(-20.222);
//            List<Double> parkLongitude = new ArrayList<>();
//            parkLongitude.add(172.12);
//            parkLongitude.add(122.12);
//        try {
//            Company.getInstance().getVehicleAPI().registerBicycles(aerodynamicCoefficient2, frontalArea2, weight2, size2, description2, parkLatitude, parkLongitude);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="facade.addParks">
//        Facade facade = new Facade();
//        facade.addParks("testFiles/parks.txt");
        //</editor-fold>

        //<editor-fold desc="Facade addBicycles and addScooters">
//        Facade facade = new Facade();
//        facade.addBicycles("testFiles/bicycles.txt");
//        facade.addEscooters("testFiles/scooters.txt");
        //</editor-fold>

        //<editor-fold desc="facade.removePark">
        //        Facade facade = new Facade();
//        facade.removePark("doggo park");
        //</editor-fold>

        //<editor-fold desc="facade.getNumberOfBicyclesAtPark & getNumberOfEScootersAtPark">
//        Facade facade = new Facade();
//        int val = facade.getNumberOfBicyclesAtPark("doggo park", "test.txt");
//        int val2 = facade.getNumberOfBicyclesAtPark(50, 180, "test2.txt");
//        int val3 = facade.getNumberOfEScootersAtPark("doggo park", "test3.txt");
//        int val4 = facade.getNumberOfEscootersAtPark(50, 180, "test4.txt");
//        int val5 = facade.getNumberOfEscootersAtPark(90, 150.56, "test5.txt");
//        System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="facade.getNearestParks">
//        Facade facade = new Facade();
//            facade.getNearestParks(18.222, 22.12, "testFiles/temp/getNearestParks.output");
        //</editor-fold>

        //<editor-fold desc="Facade unlockVehicle - unlockBicycle & unlockEscooter">
//        try {
//            Facade facade = new Facade();
//            System.out.println(facade.unlockBicycle("PT003", "diogo64"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="Test sendEmail">
//        try {
//            Properties properties =
//                    new Properties(System.getProperties());
//            InputStream input = new FileInputStream("target/classes/application.propert");
//            properties.load(input);
//            input.close();
//            System.setProperties(properties);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//        Emailer.sendEmail("1180842@isep.ipp.pt", "test", "test successful");
        //</editor-fold>

        //<editor-fold desc="Teste facade registerUser">
//        Facade facade = new Facade();
//        facade.registerUser("username", "email@gmail.com", "pass", "1234567890", 10, 20, "m");
        //</editor-fold>

        //<editor-fold desc="Facade lockVehicle">
        Facade facade = new Facade();
        facade.lockBicycle("bicycle11", "Trindade", "");
//        facade.lockBicycle("PT003", 18.222, 20.12, null);
        //</editor-fold>

        //<editor-fold desc="TripAPI fetchUnfinishedTrip">
        //        TripAPI tripAPI = Company.getInstance().getTripAPI();
//        try {
//            Trip trip = tripAPI.fetchUnfinishedTrip("c@c.c");
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="Facade getFreeSlotsAtParkForMyLoanedVehicle">
//        Facade facade = new Facade();
//        int val = facade.getFreeSlotsAtParkForMyLoanedVehicle("diogo64", "park1");
//        System.out.println(val);
        //</editor-fold>

        //<editor-fold desc="Facade getFreeBicycleSlotsAtPark & getFreeEscooterSlotsAtPark">
//        Facade facade = new Facade();
//        int v1 = facade.getFreeBicycleSlotsAtPark("park1", "asdasdasd");
//        int v2 = facade.getFreeEscooterSlotsAtPark("park1", "dasasddasasd");
//        System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="fetchUnpaidInvoicesFor & fetchLastInvoicesFor">
//        try {
//            List<Invoice> invoices = Company.getInstance().getInvoiceAPI().fetchUnpaidInvoicesFor("a@a.a");
//            Invoice invoice2 = Company.getInstance().getInvoiceAPI().fetchLastInvoiceFor("a@a.a");
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="fetchAllClientTrips">
        //        try {
//            List<Trip> t = Company.getInstance().getTripAPI().fetchAllClientTrips("b@b.b");
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="fetchUserTripsInDebt">
//                TripAPI tripAPI = Company.getInstance().getTripAPI();
//        try {z
//            List<Trip> trips = tripAPI.fetchUserTripsInDebt("diogo64");
//            System.out.println("a1");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="facade.getUserCurrentDebt & facade.getUserCurrentDebtForAllUnpaidInvoices">
//        Facade facade = new Facade();
//        double d1 = facade.getUserCurrentDebt("diogo64", "test.txt");
//        double d2 = facade.getUserCurrentDebtForAllUnpaidInvoices("diogo64", "test2.txt");
//        System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="facade.getUserCurrentPoints">
//        Facade facade = new Facade();
//        double val = facade.getUserCurrentPoints("diogo64", "test.txt");
//        System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="getTripVehicleIsIn">
        //        TripAPI tripAPI = Company.getInstance().getTripAPI();
//        try {
//            Trip trip = tripAPI.getTripVehicleIsIn("PT003");
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="fetchAllVehicles">
        //        VehicleAPI vehicleAPI = Company.getInstance().getVehicleAPI();
//        try {
//            List<Vehicle> a = vehicleAPI.fetchAllVehicles(VehicleType.ELECTRIC_SCOOTER);
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="facade.forHowLongAVehicleIsUnlocked">
//        Facade facade = new Facade();
//        long a = facade.forHowLongAVehicleIsUnlocked("PT003");
//        System.out.println("a");
        //</editor-fold>

        //<editor-fold desc="invoiceAPI.fetchInvoice">
        //        InvoiceAPI invoiceAPI = Company.getInstance().getInvoiceAPI();
//        try {
//            List<Invoice> invoices = invoiceAPI.fetchUnpaidInvoicesFor("a@a.a");
//            Invoice invoice1 = invoiceAPI.fetchInvoice("a@a.a", invoices.get(0).getPaymentStartDate());
//            Invoice invoice2 = invoiceAPI.fetchInvoice("a@a.a", invoices.get(1).getPaymentStartDate());
//            System.out.println("a");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
        //</editor-fold>

        //<editor-fold desc="facade.getInvoiceForMonth">
//        Facade facade = new Facade();
//        double result = facade.getInvoiceForMonth(2, "diogo64", "test.csv");
//        System.out.println("a");
        //</editor-fold>

        Shutdown.shutdown();
    }
}

