/**
 * Package location for Model concepts.
 */
package lapr.project.model;
