/**
 * Package location for Apllication Controllers concepts.
 */
package lapr.project.controller;
