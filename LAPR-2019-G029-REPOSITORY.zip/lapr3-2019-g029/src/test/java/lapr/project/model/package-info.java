/**
 * Package location for Model concept tests.
 */
package lapr.project.model;
